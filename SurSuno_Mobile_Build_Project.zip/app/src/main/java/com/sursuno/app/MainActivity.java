package com.sursuno.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.media.MediaPlayer;
import java.util.ArrayList;

public class MainActivity extends Activity {
    int bg=Color.rgb(16,16,24), panel=Color.rgb(27,27,40), text=Color.rgb(248,246,255), muted=Color.rgb(165,162,183), lime=Color.rgb(183,255,84), purple=Color.rgb(89,58,164);
    LinearLayout root, list; EditText search; TextView nowTitle, nowArtist, playBtn; MediaPlayer player; Uri currentUri; boolean isPlaying=false;
    ArrayList<Uri> uris=new ArrayList<>(); ArrayList<String> names=new ArrayList<>();
    String[] titles={"Neon Dreams","Ocean After Dark","Desi Moonlight","Run It Up","Cloud Nine","City Lights"};
    String[] artists={"SurSuno Sessions","The Blue Hours","Rang Studio","Pulse District","Mellow Avenue","Nova Lane"};
    String[] moods={"Pop","Chill","Desi","Workout","Chill","Pop"};
    String[] emojis={"🌃","🌊","🌙","⚡","☁️","🌆"};
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg); build();}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a,int b,int c,int d){v.setPadding(a,b,c,d);}
    TextView button(String s,int color,int fg){TextView t=label(s,13,fg,true);t.setGravity(Gravity.CENTER);t.setPadding(14,12,14,12);t.setBackground(shape(color,40));return t;}
    void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);root=column();root.setBackgroundColor(bg);sc.addView(root);setContentView(sc);
        LinearLayout header=row();pad(header,20,20,20,12);TextView logo=label("♫",24,bg,true);logo.setGravity(Gravity.CENTER);logo.setBackground(shape(lime,15));header.addView(logo,new LinearLayout.LayoutParams(46,46));TextView brand=label("  SurSuno",25,text,true);header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));TextView avatar=label("S",18,text,true);avatar.setGravity(Gravity.CENTER);avatar.setBackground(shape(purple,60));header.addView(avatar,new LinearLayout.LayoutParams(42,42));root.addView(header);
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(text);search.setHintTextColor(muted);search.setHint("⌕  Search songs, artists…");search.setPadding(16,4,16,4);search.setBackground(shape(panel,18));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,54);sp.setMargins(20,5,20,20);root.addView(search,sp);
        LinearLayout hero=column();pad(hero,22,22,22,22);hero.setBackground(shape(purple,25));TextView ey=label("YOUR SOUND. YOUR VIBE.",11,0xFFD8CAFF,true);hero.addView(ey);TextView title=label("Feel every\\nbeat.",31,text,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,-2);tp.topMargin=8;hero.addView(title,tp);TextView desc=label("Discover music. Keep your favourites close.",12,0xFFE0D8FF,false);LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-2,-2);dp.topMargin=6;hero.addView(desc,dp);TextView explore=button("▶   Explore music",lime,bg);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-2,-2);ep.topMargin=16;hero.addView(explore,ep);explore.setOnClickListener(v->list.smoothScrollTo(0,0));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.setMargins(20,0,20,22);root.addView(hero,hp);
        TextView moodhead=label("Browse mood",19,text,true);pad(moodhead,20,0,20,12);root.addView(moodhead);LinearLayout moodsRow=row();pad(moodsRow,20,0,20,12);String[] ms={"For you","Chill","Pop","Desi","Workout"};for(String m:ms){TextView chip=button(m,m.equals("For you")?lime:panel,m.equals("For you")?bg:muted);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);cp.setMargins(0,0,7,0);moodsRow.addView(chip,cp);chip.setOnClickListener(v->{search.setText(m.equals("For you")?"":m);renderSongs();});}root.addView(moodsRow);
        TextView head=label("Trending tracks",20,text,true);pad(head,20,10,20,3);root.addView(head);TextView sub=label("A little something for your playlist",12,muted,false);pad(sub,20,0,20,12);root.addView(sub);
        list=column();pad(list,20,0,20,10);root.addView(list);renderSongs();
        TextView own=label("Your own music",19,text,true);pad(own,20,16,20,10);root.addView(own);
        TextView importBtn=button("＋  Import audio from your phone",panel,lime);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.setMargins(20,0,20,12);root.addView(importBtn,ip);importBtn.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(i,100);});
        nowTitle=label("Nothing playing",13,text,true);nowArtist=label("Choose a track or import audio",11,muted,false);playBtn=button("▶",lime,bg);
        LinearLayout mini=row();mini.setBackground(shape(Color.rgb(42,39,55),18));pad(mini,12,9,12,9);LinearLayout info=column();info.addView(nowTitle);info.addView(nowArtist);mini.addView(info,new LinearLayout.LayoutParams(0,-2,1));mini.addView(playBtn,new LinearLayout.LayoutParams(48,45));LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.setMargins(12,8,12,10);root.addView(mini,mp);playBtn.setOnClickListener(v->toggle());
        TextView nav=label("⌂  Home             ⌕  Explore             ▤  Library             ⇩  Downloads",12,lime,true);nav.setGravity(Gravity.CENTER);pad(nav,4,18,4,20);root.addView(nav);
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){renderSongs();}public void afterTextChanged(android.text.Editable e){}});
    }
    void renderSongs(){if(list==null)return;list.removeAllViews();String q=search==null?"":search.getText().toString().toLowerCase();for(int i=0;i<titles.length;i++){final int idx=i;if(!(titles[i]+" "+artists[i]+" "+moods[i]).toLowerCase().contains(q))continue;LinearLayout r=row();pad(r,0,6,0,6);TextView art=label(emojis[i],24,text,true);art.setGravity(Gravity.CENTER);art.setBackground(shape(new int[]{0xFF5135A7,0xFF164E76,0xFF7A2D80,0xFFA83C31,0xFF466F9C,0xFF203D82}[i],15));r.addView(art,new LinearLayout.LayoutParams(58,58));LinearLayout inf=column();pad(inf,12,0,4,0);inf.addView(label(titles[i],14,text,true));inf.addView(label(artists[i]+" · "+moods[i],11,muted,false));r.addView(inf,new LinearLayout.LayoutParams(0,-2,1));TextView play=button("▶",panel,text);r.addView(play);play.setOnClickListener(v->{nowTitle.setText(titles[idx]);nowArtist.setText(artists[idx]+" · Demo track");toast("Demo track selected. Import audio to play real music.");});TextView dl=button("⇩",Color.rgb(31,47,26),lime);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(5,0,0,0);r.addView(dl,lp);dl.setOnClickListener(v->toast("No downloadable audio attached to this sample track."));list.addView(r);}}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==100&&result==RESULT_OK&&data!=null){if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)addAudio(data.getClipData().getItemAt(i).getUri());}else if(data.getData()!=null)addAudio(data.getData());}}
    void addAudio(Uri uri){try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}uris.add(uri);String name=uri.getLastPathSegment();try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(ix>=0)name=c.getString(ix);}}final Uri u=uri;TextView item=button("🎧  "+name+"     ▶ Play",panel,text);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(20,0,20,8);root.addView(item,root.indexOfChild(nowTitle),p);item.setOnClickListener(v->playUri(u,name));toast("Audio imported. Tap its row to play.");}
    void playUri(Uri uri,String name){try{if(player!=null){player.release();player=null;}player=new MediaPlayer();player.setDataSource(this,uri);player.setOnPreparedListener(mp->{mp.start();isPlaying=true;playBtn.setText("Ⅱ");nowTitle.setText(name);nowArtist.setText("Playing from your device");});player.setOnCompletionListener(mp->{isPlaying=false;playBtn.setText("▶");});player.prepareAsync();currentUri=uri;}catch(Exception e){toast("Could not open this audio file.");}}
    void toggle(){if(player==null){toast("Import an audio file first.");return;}if(isPlaying){player.pause();isPlaying=false;playBtn.setText("▶");}else{player.start();isPlaying=true;playBtn.setText("Ⅱ");}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}